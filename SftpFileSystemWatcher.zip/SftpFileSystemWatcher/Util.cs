﻿using SftpFileSystemWatcher;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Text;
using System.Net.Mail;

namespace FileSystemWatcherDir
{
	public class Util
	{
		//public static string logFileName;
		//public static string errorLogFileName;

		/// <summary>
		/// Static Constructor
		/// </summary>
		static Util()
		{
			//logFileName = GetSetting("LOGFILENAME");
			//errorLogFileName = GetSetting("ERRORLOGFILENAME");

			//IsDirectoryPresent(StripDirectoryName(logFileName), true);
			//IsDirectoryPresent(StripDirectoryName(errorLogFileName), true);
		}


		/// <summary>
		/// Gets The File Name From Specified Path
		/// </summary>
		public static string GetFileNameFromPath(string path)
		{
			string fileName = @"";
			int indexOfLastSlash = 0;
			try
			{
				indexOfLastSlash = path.LastIndexOf(@"\");
				fileName = path.Substring(indexOfLastSlash + 1);
				return fileName;
			}
			catch (Exception ex)
			{
				throw;
			}
			finally
			{
			}
		}

		/// <summary>
		/// Gets The Directory Path from the FilePath
		/// </summary>
		public static string StripDirectoryName(string path)
		{
			string direcoryPath = @"";
			int indexOfLastSlash = 0;

			try
			{
				indexOfLastSlash = path.LastIndexOf(@"\");
				direcoryPath = path.Substring(0, indexOfLastSlash);
				return direcoryPath;
			}
			catch (Exception ex)
			{
				throw;
			}
			finally
			{
			}
		}


		/// <summary>
		/// Gets Values From The Config File.
		/// </summary>
		public static bool IsDirectoryPresent(string directory, bool create)
		{
			try
			{
				if (!Directory.Exists(directory))
				{
					if (create == true)
					{
						Directory.CreateDirectory(directory);
						return true;
					}
					else
					{
						return false;
					}
				}
				else
				{
					return true;
				}
			}
			catch (Exception ex)
			{
				throw;
			}
			finally
			{
			}
		}


		/// <summary>
		/// Gets Values From The Config File.
		/// </summary>
		public static string GetSetting(string val)
		{
			try
			{
				return ConfigurationSettings.AppSettings[val];
			}
			catch (Exception ex)
			{
				throw;
			}
			finally
			{
			}
		}


        /// <summary>
        /// send mail  SendNotification
        /// </summary>
        /// <param name="objMessage"></param>
        public static void SendNotification(MessageDetail objMessage)
		{
			try
			{
             
                string path = SftpConfig.DirectoryPath;
				MailMessage objMailMessage = new MailMessage();
				//objMailMessage.To.Add("ravi.mishra@simfoni.com");
				//objMailMessage.From = new MailAddress("visteon.testing@simfoni.com");

				objMailMessage.To.Add(SftpConfig.Email);
                objMailMessage.From = new MailAddress(SftpConfig.SftpUserEmail);
				objMailMessage.Subject = CreateSubject(objMessage.Action , objMessage.FilePath);// objMessage.Action +" : " + objMessage.FileName;
                objMailMessage.Body = CreateBody(objMessage.Action , objMessage.FileName, objMessage.FilePath);

                string userName = SftpConfig.SftpUserEmail;
				string password = SftpConfig.SftpUserPassword;
				//string password = "Lar41052";
				SmtpClient SmtpClient =  new SmtpClient();
				SmtpClient.Credentials = new System.Net.NetworkCredential(userName, password);
				SmtpClient.Host = SftpConfig.SmtpHost;// "smtp.office365.com";
				SmtpClient.Port = SftpConfig.SmtpPort;// 587;
				SmtpClient.EnableSsl = true;
				SmtpClient.Send(objMailMessage);
			}
			catch (Exception ex)
			{

				throw ex;
			}

		}

        private static string CreateBody(string action, string fileName, string filepath)
        {
			string Body = string.Empty;
            string name = string.Empty;
            string fname = fileName;
            string timendate = DateTime.Now.ToString("MM/dd/yyyy h:mm tt");
            string subject = string.Empty;
            char seprator = '/';
            int custIndex = 2;

            try
            {

                seprator = SftpConfig.Seperator;
                custIndex = SftpConfig.CustomerIndex;

                var path = filepath.Split(seprator);
                name = path[custIndex].ToString();

                if (action.ToUpper() == "CREATED")
                    Body = $"Dear team,\r\n\r\nData of customer {name} is available on SFTP. You can download the file from the respective folder to initiate further processing.\r\n\r\nFile Name:{fname} \r\n\r\nDate:{timendate}\r\n\r\nThanks!";
                if (action.ToUpper() == "DELETED")
                    Body = $"Dear team,\r\n\r\nData file is deleted by {name}.\r\n\r\nFile Name: {fname}\r\n\r\nDate:{timendate}\r\n\r\nThanks!";
                if (action.ToUpper() == "RENAMED")
                    Body = $"Dear team,\r\n\r\nData is modified by customer {name} and is available on SFTP. You can download the file from the respective folder to initiate further processing.\r\n\r\nFile Name: {fname}\r\n\r\nDate:{timendate}\r\n\r\nThanks!";
            }
			catch (Exception)
			{

				throw;
			}
            return Body;
        }

        private static string CreateSubject(string action, string fileName)
        {
			string subject = string.Empty;
            char seprator = '/';
			int custIndex = 2;

            try
			{
               
                seprator = SftpConfig.Seperator;
                custIndex = SftpConfig.CustomerIndex;

                var path = fileName.Split(seprator);
				string customer = path[custIndex].ToString();

				if (action.ToUpper() == "CREATED")
					subject = "New File uploaded by ";
                if (action.ToUpper() == "RENAMED")
                    subject = "File modified by ";
                if (action.ToUpper() == "DELETED")
                    subject = "File deleted by ";

				subject = subject + customer;

            }
			catch (Exception)
			{

				throw;
			}
			return subject;
        }
    }
    public class Action
    {
        public const string Created = "CREATED";
        public const string Deleted = "DELETED";
        public const string Renamed = "RENAMED";
        public const string Changed = "CHANGED";

    }
}
