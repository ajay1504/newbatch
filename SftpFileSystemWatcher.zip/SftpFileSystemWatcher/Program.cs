﻿using log4net;
using log4net.Repository.Hierarchy;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;
using SftpFileSystemWatcher;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;


namespace FileSystemWatcherDir
{
    public class Program
    {

        public static readonly ILog _log = LogManager.GetLogger(typeof(Program));

        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        // [STAThread]
        public static async Task Main(string[] args)
        {
            Logger.InitilizeLogger(_log);
            try
            {
                var configFilePath = Environment.GetEnvironmentVariable("ConfigFilePath");
                // Console.WriteLine($"Config file path: {configFilePath}");
                
                _log.Info($"Config file path: {configFilePath}");

                SftpConfig _serviceConfig = JsonConvert.DeserializeObject<SftpConfig>(File.ReadAllText(configFilePath));

                using var host = Host.CreateDefaultBuilder(args)
                    .ConfigureServices((hostContext, services) =>
                    {
                        services.AddHostedService<FileDirWatcher>();
                        services.AddSingleton<IXeevaLogger, XeevaLogger>();
                    })
                    .Build();

                await host.StartAsync();
                await host.WaitForShutdownAsync();
            }
            catch (Exception ex)
            {
                _log.Error($"{ex.Message}, Inner exception: {ex.InnerException?.Message}");
            }
        }
    }
}
