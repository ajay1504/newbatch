﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace SftpFileSystemWatcher
{
 
      public class SftpConfig
    {
        [JsonProperty("SftpUserEmail")]
        public static string SftpUserEmail { get; set; }


        [JsonProperty("SftpUserPassword")]
        public static string SftpUserPassword { get; set; }

        [JsonProperty("SmtpHost")]
        public static string SmtpHost { get; set; }

        [JsonProperty("SmtpPort")]
        public static int SmtpPort { get; set; }

        [JsonProperty("SsleEnable")]
        public static bool SsleEnable { get; set; }

        [JsonProperty("Email")]
        public static string Email { get; set; }

        [JsonProperty("DirectoryPath")]
        public static string DirectoryPath { get; set; }

        [JsonProperty("Subdirectory")]
        public static bool Subdirectory { get; set; }

        [JsonProperty("CustomerIndex")]
        public static int CustomerIndex { get; set; }

        [JsonProperty("Seperator")]
        public static char Seperator { get; set; }
    }
}
