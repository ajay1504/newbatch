﻿using Microsoft.Extensions.Hosting;
using SftpFileSystemWatcher;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Mail;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FileSystemWatcherDir
{
    public class FileDirWatcher : IHostedService, IDisposable
    {

        private Timer _timer;
        IXeevaLogger _logger;
        private bool isInProgress;
        private System.IO.FileSystemWatcher FSWatcher;
        public FileDirWatcher(IXeevaLogger logger)
        {

            _logger = logger;
            logger.Log4NetCore = Program._log;
            InitializeComponent();

        }
        private void InitializeComponent()
        {
            this.FSWatcher = new System.IO.FileSystemWatcher();
            ((System.ComponentModel.ISupportInitialize)(this.FSWatcher)).BeginInit();
            // 
            // FSWatcher
            // 
            this.FSWatcher.EnableRaisingEvents = true;
            this.FSWatcher.IncludeSubdirectories = true;

            this.FSWatcher.NotifyFilter = ((System.IO.NotifyFilters)((((((((System.IO.NotifyFilters.FileName | System.IO.NotifyFilters.DirectoryName)
                | System.IO.NotifyFilters.Attributes)
                | System.IO.NotifyFilters.Size)
                | System.IO.NotifyFilters.LastWrite)
                | System.IO.NotifyFilters.LastAccess)
                | System.IO.NotifyFilters.CreationTime)
                | System.IO.NotifyFilters.Security)));


            this.FSWatcher.Path = SftpConfig.DirectoryPath;
            //this.FSWatcher.Path = "D:\\BACKUP\\New folder";
            this.FSWatcher.Deleted += new System.IO.FileSystemEventHandler(this.FSWatcher_Deleted);
            this.FSWatcher.Renamed += new System.IO.RenamedEventHandler(this.FSWatcher_Renamed);
            this.FSWatcher.Changed += new System.IO.FileSystemEventHandler(this.FSWatcher_Changed);
            this.FSWatcher.Created += new System.IO.FileSystemEventHandler(this.FSWatcher_Created);
            // 
            // FileSysWatcher
            // 
            //this.CanHandlePowerEvent = true;
            //this.CanPauseAndContinue = true;
            //this.CanShutdown = true;
            //this.ServiceName = "File and System Watcher";
            ((System.ComponentModel.ISupportInitialize)(this.FSWatcher)).EndInit();

        }

        /// <summary>
        /// Event occurs when the contents of a File or Directory is changed
        /// </summary>
        private void FSWatcher_Changed(object sender, System.IO.FileSystemEventArgs e)
        {
           
                string message = @"";
                MessageDetail objMessage = new MessageDetail();
                try
                {
                    message = Util.GetFileNameFromPath(e.Name);
                    message = message + "," + e.FullPath;
                    message = message + "," + Action.Changed;
                    // message = message + "," + userName;
                    message = message + "," + System.DateTime.Now.Date.ToShortDateString();
                    message = message + "," + System.DateTime.Now.TimeOfDay.ToString();
                    objMessage.FileName = e.Name;
                    objMessage.FilePath = e.FullPath;
                    objMessage.Action = Action.Changed;
                    // Util.WriteToLogFile(message, objMessage);
                  //  Util.SendNotification(objMessage);
                    _logger.LogInfo(message);
                }
                catch (Exception ex)
                {
                    //Util.WriteToErrorLogFile(ex);
                    _logger.LogError($"File processing(Changed)  {ex.Message}, Inner exception: {ex.InnerException?.Message}");
                }
                finally
                {
                }
           // }
        }


        /// <summary>
        /// Event occurs when the a File or Directory is created
        /// </summary>
        private void FSWatcher_Created(object sender, System.IO.FileSystemEventArgs e)
        {
            string message = @"";
            MessageDetail objMessage = new MessageDetail();
            try
            {
                message = Util.GetFileNameFromPath(e.Name);
                message = message + "," + e.FullPath;
                message = message + "," + Action.Created;
                // message = message + "," + userName;
                message = message + "," + System.DateTime.Now.Date.ToShortDateString();
                message = message + "," + System.DateTime.Now.TimeOfDay.ToString();
                objMessage.FileName = e.Name;
                objMessage.FilePath = e.FullPath;
                objMessage.Action = Action.Created;
                _logger.LogInfo(message);
                Util.SendNotification(objMessage);
               // Util.WriteToLogFile(message, objMessage);
            }
            catch (Exception ex)
            {
                _logger.LogError($"File processing(Created)  {ex.Message}, Inner exception: {ex.InnerException?.Message}");
                // Util.WriteToErrorLogFile(ex);
            }
            finally
            {
            }
        }


        /// <summary>
        /// Event occurs when the a File or Directory is deleted
        /// </summary>
        private void FSWatcher_Deleted(object sender, System.IO.FileSystemEventArgs e)
        {
            string message = @"";
            MessageDetail objMessage = new MessageDetail();
            try
            {
                message = Util.GetFileNameFromPath(e.Name);
                message = message + "," + e.FullPath;
                message = message + "," + Action.Deleted;
                //message = message + "," + userName;
                message = message + "," + System.DateTime.Now.Date.ToShortDateString();
                message = message + "," + System.DateTime.Now.TimeOfDay.ToString();

                objMessage.FileName = e.Name;
                objMessage.FilePath = e.FullPath;
                objMessage.Action = Action.Deleted;
                _logger.LogInfo(message);
                Util.SendNotification(objMessage);
                // Util.WriteToLogFile(message, objMessage);
            }
            catch (Exception ex)
            {
                _logger.LogError($"File processing(Deleted)  {ex.Message}, Inner exception: {ex.InnerException?.Message}");
                // Util.WriteToErrorLogFile(ex);
            }
            finally
            {
            }
        }


        /// <summary>
        /// Event occurs when the a File or Directory is renamed
        /// </summary>
        private void FSWatcher_Renamed(object sender, System.IO.RenamedEventArgs e)
        {
            string message = @"";
            MessageDetail objMessage = new MessageDetail();
            try
            {
                message = Util.GetFileNameFromPath(e.Name);
                message = message + "," + e.FullPath;
                message = message + "," + Action.Renamed +  " To " + Util.GetFileNameFromPath(e.OldName);
                //message = message + "," + userName;
                message = message + "," + System.DateTime.Now.Date.ToShortDateString();
                message = message + "," + System.DateTime.Now.TimeOfDay.ToString();
                objMessage.FileName = e.Name;
                objMessage.FilePath = e.FullPath;
                objMessage.Action = Action.Renamed;
                _logger.LogInfo(message);
                Util.SendNotification(objMessage);
                //  Util.WriteToLogFile(message, objMessage);
            }
            catch (Exception ex)
            {
                _logger.LogError($"File processing(Renamed)  {ex.Message}, Inner exception: {ex.InnerException?.Message}");
                // Util.WriteToErrorLogFile(ex);
            }
            finally
            {
            }
        }
        public Task StartAsync(CancellationToken stoppingToken)
        {
            try
            {
                isInProgress = false;
                //   _logger.LogInfo("Service started.");

                _timer = new Timer(DoWork, null, TimeSpan.Zero, TimeSpan.FromSeconds(3600));
            }
            catch (Exception ex)
            {
                _logger.LogError($"File processing(StartAsync)  {ex.Message}, Inner exception: {ex.InnerException?.Message}");
            }

            return Task.CompletedTask;
        }

        //this will be called on time interval
        private void DoWork(object state)
        {
            try
            {
                if (!isInProgress)
                {

                    isInProgress = true;
                    //_logger.LogInfo($"Started.");
                    //_logger.LogInfo($"completed.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"File processing(Dowork)  {ex.Message}, Inner exception: {ex.InnerException?.Message}");
            }
            finally
            {
                isInProgress = false;
            }
        }

        public Task StopAsync(CancellationToken stoppingToken)
        {
            try
            {
                //_logger.LogInfo("Service is stopping.");

                _timer?.Change(Timeout.Infinite, 0);
            }
            catch (Exception ex)
            {
                _logger.LogError($"File processing(StopAsync)  {ex.Message}, Inner exception: {ex.InnerException?.Message}");
            }

            return Task.CompletedTask;
        }

        public void Dispose()
        {
            try
            {
                _timer?.Dispose();
            }
            catch (Exception ex)
            {
                _logger.LogError($"File processing (Dispose)  {ex.Message}, Inner exception: {ex.InnerException?.Message}");
            }
        }

        private void LogEvents(bool loginfo, string data)
        {
            if (loginfo)
            {
                // _logger.LogInfo(data);
            }

        }








    }
}
