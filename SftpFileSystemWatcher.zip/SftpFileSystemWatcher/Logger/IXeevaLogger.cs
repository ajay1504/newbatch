﻿using log4net;
using System;
using System.Collections.Generic;
using System.Text;

namespace FileSystemWatcherDir
{
    public interface IXeevaLogger
    {
        void LogError(string message);
        void LogInfo(string message);
        ILog Log4NetCore { get; set; }
    }
}
